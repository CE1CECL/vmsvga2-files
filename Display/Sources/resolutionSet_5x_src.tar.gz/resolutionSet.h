/*
 *  resolutionSet.h
 *  resolutionSet
 *
 *  Created by Zenith432 on October 2nd 2010.
 *  Copyright 2010-2013 Zenith432. All rights reserved.
 *
 */

#ifndef __RESOLUTIONSET_H__
#define __RESOLUTIONSET_H__

#include <sys/cdefs.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * From glib.h
 */
typedef struct _GArray
{
	char *data;
	unsigned len;
} GArray;

void g_log(char const* log_domain, int log_level, char const* format, ...) __printflike(3, 4);
char* g_strdup_printf(char const* format, ...) __printflike(1, 2);
void g_free(void* mem);
void g_return_if_fail_warning(char const* log_domain, char const* pretty_function, char const* expression);

/*
 * From Open VM Tools
 */
typedef struct _ToolsPluginData {
	char const* name;
	GArray* regs;
	void* errorCb;
	void* _private;
} ToolsPluginData;

typedef struct _ToolsAppCtx {
	int version;
	char const* name;
	int isVMware;
	int errorCode;
	void* mainLoop;
	struct _RpcChannel* rpc;
	void* config;
	int blockFD;
	char const** envp;
	void* serviceObj;
} ToolsAppCtx;

typedef struct _ToolsPluginSignalCb {
	char const* signame;
	void* callback;
	void* clientData;
} ToolsPluginSignalCb;

typedef struct _ToolsAppReg {
	int type;
	GArray* data;
} ToolsAppReg;

typedef struct _ToolsAppCapability {
	int type;
	char const* name;
	int index;
	unsigned value;
} ToolsAppCapability;

typedef struct _RpcInData {
	char const* name;
	char const* args;
	size_t argsSize;
	char* result;
	size_t resultLen;
	int freeResult;
	void* appCtx;
	void* clientData;
} RpcInData;

typedef int (*RpcIn_Callback)(RpcInData *data);

typedef struct _RpcChannelCallback {
	char const* name;
	RpcIn_Callback callback;
	void* clientData;
	void* xdrIn;
	void* xdrOut;
	size_t xdrInSize;
} RpcChannelCallback;

typedef struct _RpcChannel {
	void* start;
	void* stop;
	int (*send)(struct _RpcChannel*,char const*,size_t,char**,size_t*);
	void* setup;
	void* shutdown;
	void* _private;
} RpcChannel;

typedef struct _ResolutionInfoType {
	char initialized;                    // TRUE if successfully initialized.
	char canSetResolution;               // TRUE if back-end supports Resolution_Set.
	char canSetTopology;                 // TRUE if back-end supports DisplayTopology_Set.
} ResolutionInfoType;

typedef struct _DisplayTopologyInfo {
	int x;
	int y;
	int width;
	int height;
} DisplayTopologyInfo;

typedef struct _ResolutionInfoOSXType {
	unsigned flags;
	unsigned w;
	unsigned h;
} ResolutionInfoOSXType;

/*
 * Imports from libvmtools.dylib
 */
GArray* VMTools_WrapArray(void const* data, unsigned elemSize, unsigned count);
void Panic(const char* fmt, ...) __attribute__((noreturn)) __printflike(1, 2);
int RpcChannel_SetRetVals(RpcInData* data, char const *result, int retVal);
char StrUtil_GetNextUintToken(unsigned* out, unsigned* index, char const* str, char const* delimiters);

#ifdef __cplusplus
}
#endif

#endif
