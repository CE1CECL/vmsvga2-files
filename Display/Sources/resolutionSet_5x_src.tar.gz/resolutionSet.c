/*
 *  resolutionSet.c
 *  resolutionSet
 *
 *  Created by Zenith432 on October 2nd 2010.
 *  Copyright 2010-2013 Zenith432. All rights reserved.
 *
 */

#include <IOKit/IOKitLib.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <unistd.h>
#include "resolutionSet.h"

#define RPCIN_SETRETVALS RpcChannel_SetRetVals

#define RESOLUTION_SET_CAPABILITIES_MAX 5

#define ARRAYSIZE(a) (sizeof (a) / sizeof *(a))

#define Debug(...) g_log(&logDomain[0], 128, __VA_ARGS__)
#define Warning(...) g_log(&logDomain[0], 16, __VA_ARGS__)

static __attribute__((used)) char const copyright[] = "Copyright 2010-2013 Zenith432";

static char const logDomain[] = "resolutionSet";

static char const* rpcChannelName = 0;
static ToolsPluginData regData = {
	"resolutionSet",
	0,
	0,
	0
};
ResolutionInfoType resolutionInfo;

#pragma mark -
#pragma mark Provider Helpers
#pragma mark -

struct Provider
{
	io_service_t service;
	int clientIndex;
	int methodIndex;
};

static inline
io_service_t tryFindService(char const* class)
{
	return IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching(class));
}

static
kern_return_t getProvider(struct Provider* pProvider)
{
	int gfx, count;
	io_service_t svc;

	if (!pProvider)
		return KERN_INVALID_ARGUMENT;
	for (gfx = 0, count = 0; count < 60; ++count) {
		svc = tryFindService("VMsvga2");
		if (!svc) {
			svc = tryFindService("VMwareGfx");
			if (!svc) {
				sleep(1);
				continue;
			}
			gfx = 1;
		}
		pProvider->service = svc;
		pProvider->clientIndex = gfx ? 0 : 2;
		pProvider->methodIndex = gfx ? 0 : 3;
		return KERN_SUCCESS;
	}
	return KERN_INVALID_NAME;
}

#pragma mark -
#pragma mark Main Code
#pragma mark -

void* ResolutionToolkitInit(void)
{
	return 0;
}

char ResolutionSetTopology(unsigned ndisplays, DisplayTopologyInfo* topology)
{
	return 0;
}

void ResolutionBackendCleanup(void)
{
}

static void ResolutionCleanup(void)
{
	if (!resolutionInfo.initialized)
		return;

	ResolutionBackendCleanup();
}

static char ResolutionCanSet(void)
{
	struct Provider provider;

	if (getProvider(&provider) != KERN_SUCCESS) {
		Debug("%s: Unable to find the service.\n", __FUNCTION__);
		return 0;
	}
	IOObjectRelease(provider.service);
	return 1;
}

int ResolutionBackendInit(void* handle)
{
	resolutionInfo.canSetResolution = ResolutionCanSet();
	resolutionInfo.canSetTopology = 0;
	return 1;
}

static char ResolutionInit(void* handle)
{
	if (!ResolutionBackendInit(handle))
		return 0;

	resolutionInfo.initialized = 1;

	return 1;
}

char ResolutionSetResolution(unsigned w, unsigned h)
{
	struct Provider provider;
	kern_return_t krt;
	io_connect_t connect;
	size_t outputStructCount;
	ResolutionInfoOSXType inputStruct, outputStruct;

	Debug("%s: requested width,height -> %u,%u\n",
		  __FUNCTION__,
		  w,
		  h);
	krt = getProvider(&provider);
	if (krt != KERN_SUCCESS) {
		Debug("%s: Unable to find the service.\n", __FUNCTION__);
		return 0;
	}
	krt = IOServiceOpen(provider.service,
						mach_task_self(),
						provider.clientIndex,
						&connect);
	IOObjectRelease(provider.service);
	if (krt != KERN_SUCCESS) {
		Debug("%s: Unable to open the service, error == %#x\n", __FUNCTION__, krt);
		return 0;
	}
	outputStructCount = sizeof outputStruct;
	inputStruct.flags = 1U;
	inputStruct.w = w;
	inputStruct.h = h;
	krt = IOConnectCallStructMethod(connect,
									provider.methodIndex,
									&inputStruct,
									sizeof inputStruct,
									&outputStruct,
									&outputStructCount);
	IOServiceClose(connect);
	if (krt != KERN_SUCCESS) {
		Debug("%s: Unable to issue the ioctl, error == %#x.\n", __FUNCTION__, krt);
		return 0;
	}
	Debug("%s: actual width,height -> %u,%u\n",
		  __FUNCTION__,
		  outputStruct.w,
		  outputStruct.h);
	return 1;
}

static int ResolutionResolutionSetCB(RpcInData *data)
{
	unsigned width = 0U;
	unsigned height = 0U;
	unsigned index = 0U;
	int retval = 0;

	if (!resolutionInfo.initialized) {
		Debug("%s: FAIL! Request for resolution set but plugin is not initialized\n", __FUNCTION__);
		return RPCIN_SETRETVALS(data, "Invalid guest state: resolution set not initialized", 0);
	}

	if (!StrUtil_GetNextUintToken(&width, &index, data->args, " "))
		goto invalid_arguments;
	if (!StrUtil_GetNextUintToken(&height, &index, data->args, ""))
		goto invalid_arguments;

	retval = ResolutionSetResolution(width, height);

invalid_arguments:
	return RPCIN_SETRETVALS(data, retval ? "" : "Invalid arguments", retval);
}

static int ResolutionDisplayTopologySetCB(RpcInData *data)
{
	DisplayTopologyInfo* displays = 0;
	unsigned count, i;
	int success = 0;
	char const* p;

	if (!resolutionInfo.initialized) {
		Debug("%s: FAIL! Request for topology set but plugin is not initialized\n", __FUNCTION__);
		RPCIN_SETRETVALS(data, "Invalid guest state: topology set not initialized", 0);
		goto out;
	}

	if (sscanf(data->args, "%u", &count) != 1)
		return RPCIN_SETRETVALS(data, "Invalid arguments. Expected \"count\"", 0);

	displays = malloc(sizeof *displays * count);
	if (!displays) {
		RPCIN_SETRETVALS(data, "Failed to alloc buffer for display info", 0);
		goto out;
	}

	for (p = data->args, i = 0U; i < count; i++) {
		p = strchr(p, ',');
		if (!p) {
			RPCIN_SETRETVALS(data, "Expected comma separated display list", 0);
			goto out;
		}
		p++; /* Skip past the , */

		if (sscanf(p, " %d %d %d %d ",
				   &displays[i].x,
				   &displays[i].y,
				   &displays[i].width,
				   &displays[i].height) != 4) {
			RPCIN_SETRETVALS(data, "Expected x, y, w, h in display entry", 0);
			goto out;
		}
	}

	success = ResolutionSetTopology(count, displays);

	RPCIN_SETRETVALS(data, success ? "" : "ResolutionSetTopology failed", success);

out:
	free(displays);
	return success;
}

static int RpcChannel_Send(RpcChannel* chan,
						   char const* data,
						   size_t dataLen,
						   char** result,
						   size_t* resultLen)
{
	if (!(chan->send)) {
		g_return_if_fail_warning(&logDomain[0], __FUNCTION__, "chan->send != NULL");
		return 0;
	}

	return chan->send(chan, data, dataLen, result, resultLen);
}

static void ResolutionSetServerCapability(RpcChannel* chan, unsigned value)
{
	char* msg;

	if (!rpcChannelName) {
		Debug("Channel name is null, RPC not sent.\n");
		return;
	}

	msg = g_strdup_printf("tools.capability.resolution_server %s %u",
						  rpcChannelName,
						  value);
	if (!RpcChannel_Send(chan, msg, strlen(msg), 0, 0))
		Warning("%s: Unable to set tools.capability.resolution_server\n", __FUNCTION__);
	g_free(msg);
}

static GArray* ResolutionSetCapabilities(void* src,
										 ToolsAppCtx* ctx,
										 int set,
										 void* data)
{
	ToolsAppCapability capabilityArray[RESOLUTION_SET_CAPABILITIES_MAX];

	unsigned capabilityCount = 0U;

	Debug("%s: enter\n", __FUNCTION__);

	if (!resolutionInfo.initialized)
		return 0;

	if (resolutionInfo.canSetTopology) {
		capabilityArray[capabilityCount].type  = 0 /* TOOLS_CAP_OLD */;
		capabilityArray[capabilityCount].name  = "display_topology_set";
		capabilityArray[capabilityCount].index = 0;
		capabilityArray[capabilityCount].value = set ? 2 : 0;
		capabilityCount++;

		capabilityArray[capabilityCount].type  = 0 /* TOOLS_CAP_OLD */;
		capabilityArray[capabilityCount].name  = "display_global_offset";
		capabilityArray[capabilityCount].index = 0;
		capabilityArray[capabilityCount].value = set ? 1 : 0;
		capabilityCount++;
	}

	if (resolutionInfo.canSetResolution) {
		capabilityArray[capabilityCount].type  = 0 /* TOOLS_CAP_OLD */;
		capabilityArray[capabilityCount].name  = "resolution_set";
		capabilityArray[capabilityCount].index = 0;
		capabilityArray[capabilityCount].value = set ? 1 : 0;
		capabilityCount++;
		if (ctx && ctx->rpc && ctx->isVMware)
			ResolutionSetServerCapability(ctx->rpc, set ? 1 : 0);
	}

	return VMTools_WrapArray(&capabilityArray[0],
							 sizeof capabilityArray[0],
							 capabilityCount);
}

static void ResolutionSetShutdown(void* src,
								  ToolsAppCtx* ctx,
								  void* data)
{
	ResolutionCleanup();
}

__attribute__((visibility("default"))) ToolsPluginData* ToolsOnLoad(ToolsAppCtx* ctx)
{
	RpcChannelCallback rpcs[] = {
		{ "Resolution_Set", &ResolutionResolutionSetCB },
		{ "DisplayTopology_Set", &ResolutionDisplayTopologySetCB }
	};
	void* handle;
	ToolsPluginSignalCb sigs[] = {
		{ "tcs_capabilities", &ResolutionSetCapabilities, &regData },
		{ "tcs_shutdown", &ResolutionSetShutdown, &regData }
	};
	ToolsAppReg regs[] = {
		{ 1 /* TOOLS_APP_GUESTRPC */, 0 },
		{ 2 /* TOOLS_APP_SIGNALS */, VMTools_WrapArray(&sigs[0],
													   sizeof sigs[0],
													   ARRAYSIZE(sigs)) }
	};
	if (!ctx->isVMware)
		return 0;
	if (!strcmp(ctx->name, "vmsvc"))
		rpcChannelName = "toolbox";
	else if (!strcmp(ctx->name, "vmusr"))
		rpcChannelName = "toolbox-dnd";
	else
		Panic("NOT_REACHED %s:%d\n", __FILE__, __LINE__);
	resolutionInfo.initialized = 0;
	handle = ResolutionToolkitInit();
	ResolutionInit(handle);
	regs[0].data = VMTools_WrapArray(&rpcs[0],
									 sizeof rpcs[0],
									 ARRAYSIZE(rpcs));
	regData.regs = VMTools_WrapArray(&regs[0],
									 sizeof regs[0],
									 ARRAYSIZE(regs));
	return &regData;
}
